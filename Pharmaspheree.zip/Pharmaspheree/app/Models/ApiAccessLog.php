<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApiAccessLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'api_user_id',
        'endpoint',
        // Add additional columns as needed for access log details
    ];

    public function apiUser()
    {
        return $this->belongsTo(ApiUser::class, 'api_user_id');
    }
}
