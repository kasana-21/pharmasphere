<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Drug extends Model
{
    use HasFactory;

    protected $fillable = [
        'drug_name',
        'drug_description',
        'drug_price',
        'category_id',
        // Add additional columns as needed for drug details
    ];

    // Define relationships here if needed

    public function category()
    {
        return $this->belongsTo(DrugCategory::class, 'category_id');
    }
}
