<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApiToken extends Model
{
    use HasFactory;

    protected $fillable = [
        'api_user_id',
        'token',
        'expires_at',
        // Add additional columns as needed for token management
    ];

    protected $dates = [
        'expires_at',
    ];

    public function apiUser()
    {
        return $this->belongsTo(ApiUser::class, 'api_user_id');
    }
}
