<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Enduser extends Model
{
    use HasFactory;

    protected $fillable = [
        'fname',
        'lname',
        'SSN',
        'yearofbirth',
        'email',
        'phone',
        'username',
        'password',
        'gender',
        'usertype',
    ];

    protected $dates = [
        'yearofbirth',
    ];
}
