<?php
namespace App\Http\Controllers;

use App\Models\UserDrug;
use Illuminate\Http\Request;

class UserDrugController extends Controller
{
    public function index()
    {
        $userDrugs = UserDrug::all();

        if ($userDrugs->count() > 0) {
            $data = [
                'status' => 200,
                'user_drugs' => $userDrugs,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }
    public function store(Request $request)
        {

            $userDrug = UserDrug::create([
                'user_id' => $request->user_id,
                'drug_id' => $request->drug_id,
                // Add additional fields as needed
            ]);

            if ($userDrug) {
                return response()->json([
                    'status' => 200,
                    'message' => 'UserDrug created successfully'
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong'
                ], 500);
            }
        }
}
