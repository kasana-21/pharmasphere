<?php

namespace App\Http\Controllers;

use App\Models\ApiToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ApiTokenController extends Controller
{
    public function index()
    {
        $apiTokens = ApiToken::all();

        if ($apiTokens->count() > 0) {
            $data = [
                'status' => 200,
                'api_tokens' => $apiTokens,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'api_user_id' => 'required|exists:api_users,id',
            'token' => 'required|string|max:255',
            'expires_at' => 'required|date|after:' . now(), 
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->messages(),
            ], 422);
        } else {
            $apiToken = ApiToken::create([
                'api_user_id' => $request->api_user_id,
                'token' => $request->token,
                'expires_at' => $request->expires_at,
            ]);

            if ($apiToken) {
                return response()->json([
                    'status' => 200,
                    'message' => 'ApiToken created successfully',
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong',
                ], 500);
            }
        }
    }
}
