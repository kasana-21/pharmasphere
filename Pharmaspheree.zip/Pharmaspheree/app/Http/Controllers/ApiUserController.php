<?php

namespace App\Http\Controllers;

use App\Models\ApiUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ApiUserController extends Controller
{
    public function index()
    {
        $apiUsers = ApiUser::all();

        if ($apiUsers->count() > 0) {
            $data = [
                'status' => 200,
                'api_users' => $apiUsers,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:api_users,email|max:255',
            'password' => 'required|string|max:255',
            // Add additional validation rules as needed
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->messages(),
            ], 422);
        } else {
            $apiUser = ApiUser::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => $request->password,
                // Add additional fields as needed
            ]);

            if ($apiUser) {
                return response()->json([
                    'status' => 200,
                    'message' => 'ApiUser created successfully',
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong',
                ], 500);
            }
        }
    }
}
