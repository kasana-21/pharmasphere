<?php

namespace App\Http\Controllers;

use App\Models\Enduser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EnduserController extends Controller
{
    public function index(){
        $endusers = Enduser::all();

        if($endusers -> count() > 0){
            $data = [
                'status' => 200,
                'endusers' => $endusers
            ];
            return response() -> json($data, 200);
        }else {
            $data = [
                'status' => 404,
                'message' => 'No records found'
            ];
            return response() -> json($data, 404);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'fname' => 'required|string|max:191',
            'lname' => 'required|string|max:191',
            'SSN'=> 'required|max:191',
            'yearofbirth' => 'required|max:191',
            'email' => 'required|email|max:191',
            'phone' => 'required|digits:10',
            'username' => 'required|string|max:191',
            'password' => 'required|string|max:191',
            'gender' => 'required|string|max:191',
            'usertype' => 'required|string|max:191',
        ]);

        if($validator -> fails()){
            return response() -> json([
                'status' => 422,
                'errors' => $validator->messages()
            ], 422);
        }else{
            $enduser = Enduser::create([
                'fname' => $request->fname,
                'lname'=> $request->lname,
                'SSN'=> $request->SSN,
                'yearofbirth'=> $request->yearofbirth,
                'email'=> $request->email,
                'phone'=> $request->phone,
                'username'=> $request->username,
                'password'=> $request->password,
                'gender'=> $request->gender,
                'usertype'=> $request->usertype,
            ]);

        if($enduser){
            return response()->json([
                'status' => 200,
                'message' => 'Enduser created successfully'
            ],200);
        }else{
            return response()->json([
                'status' => 500,
                'message' => 'Something went wrong'
            ],500);
        }
        }
    }
};
