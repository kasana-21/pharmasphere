<?php

namespace App\Http\Controllers;

use App\Models\ApiKey;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ApiKeyController extends Controller
{
    public function index()
    {
        $apiKeys = ApiKey::all();

        if ($apiKeys->count() > 0) {
            $data = [
                'status' => 200,
                'api_keys' => $apiKeys,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'api_user_id' => 'required|exists:api_users,id',
            'api_key' => 'required|string|max:255',
            // Add additional validation rules as needed
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->messages(),
            ], 422);
        } else {
            $apiKey = ApiKey::create([
                'api_user_id' => $request->api_user_id,
                'api_key' => $request->api_key,
                // Add additional fields as needed
            ]);

            if ($apiKey) {
                return response()->json([
                    'status' => 200,
                    'message' => 'ApiKey created successfully',
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong',
                ], 500);
            }
        }
    }
}
