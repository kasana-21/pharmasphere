<?php
namespace App\Http\Controllers;

use App\Models\DrugCategory;
use Illuminate\Http\Request;

class DrugCategoryController extends Controller
{
    public function index()
    {
        $drugCategories = DrugCategory::all();

        if ($drugCategories->count() > 0) {
            $data = [
                'status' => 200,
                'drug_categories' => $drugCategories,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }
    public function store(Request $request)
        {

            $drugCategory = DrugCategory::create([
                'category_name' => $request->category_name,
                // Add additional fields as needed
            ]);

            if ($drugCategory) {
                return response()->json([
                    'status' => 200,
                    'message' => 'DrugCategory created successfully'
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong'
                ], 500);
            }
        }


}
