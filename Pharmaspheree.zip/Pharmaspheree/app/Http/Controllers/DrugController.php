<?php
namespace App\Http\Controllers;

use App\Models\Drug;
use Illuminate\Http\Request;

class DrugController extends Controller
{
    public function index()
    {
        $drugs = Drug::all();

        if ($drugs->count() > 0) {
            $data = [
                'status' => 200,
                'drugs' => $drugs,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }
    public function store(Request $request)
        {
            // Add your validation rules for drug creation here

            $drug = Drug::create([
                'drug_name' => $request->drug_name,
                'drug_description' => $request->drug_description,
                'drug_price' => $request->drug_price,
                'category_id' => $request->category_id,
            ]);

            if ($drug) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Drug created successfully'
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong'
                ], 500);
            }
        }

}
