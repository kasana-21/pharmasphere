<?php

namespace App\Http\Controllers;

use App\Models\ApiProduct;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ApiProductController extends Controller
{
    public function index()
    {
        $apiProducts = ApiProduct::all();

        if ($apiProducts->count() > 0) {
            $data = [
                'status' => 200,
                'api_products' => $apiProducts,
            ];
            return response()->json($data, 200);
        } else {
            $data = [
                'status' => 404,
                'message' => 'No records found',
            ];
            return response()->json($data, 404);
        }
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_name' => 'required|string|max:191',
            // Add additional validation rules as needed
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'errors' => $validator->messages(),
            ], 422);
        } else {
            $apiProduct = ApiProduct::create([
                'product_name' => $request->product_name,
            ]);

            if ($apiProduct) {
                return response()->json([
                    'status' => 200,
                    'message' => 'ApiProduct created successfully',
                ], 200);
            } else {
                return response()->json([
                    'status' => 500,
                    'message' => 'Something went wrong',
                ], 500);
            }
        }
    }
}
