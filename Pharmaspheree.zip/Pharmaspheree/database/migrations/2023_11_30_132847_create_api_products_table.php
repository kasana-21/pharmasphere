<?php

// CreateApiProductsTable.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateApiProductsTable extends Migration
{
    public function up()
    {
        Schema::create('api_products', function (Blueprint $table) {
            $table->id();
            $table->string('product_name');
            // Add additional columns as needed for API product details
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('api_products');
    }
}
