<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DrugController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ApiKeyController;
use App\Http\Controllers\EnduserController;
use App\Http\Controllers\ApiTokenController;
use App\Http\Controllers\UserDrugController;
use App\Http\Controllers\ApiProductController;
use App\Http\Controllers\ApiAccessLogController;
use App\Http\Controllers\DrugCategoryController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Route::get('users', function(){
//     return 'This is user API';
// });

Route::get('endusers', [EnduserController::class, 'index']);
Route::get('api-tokens', [ApiTokenController::class, 'index']);
Route::get('api-keys', [ApiKeyController::class, 'index']);
Route::get('api-products', [ApiProductController::class, 'index']);
Route::get('api-access-logs', [ApiAccessLogController::class, 'index']);
Route::get('drug-categories', [DrugCategoryController::class, 'index']);
Route::get('drugs', [DrugController::class, 'index']);
Route::get('user-drugs', [UserDrugController::class, 'index']);
Route::get('admins', [AdminController::class, 'index']);

Route::post('endusers', [EnduserController::class, 'store']);
Route::post('api-tokens', [ApiTokenController::class, 'store']);
Route::post('api-keys', [ApiKeyController::class, 'store']);
Route::post('api-products', [ApiProductController::class, 'store']);
Route::post('api-access-logs', [ApiAccessLogController::class, 'store']);
Route::post('drug-categories', [DrugCategoryController::class, 'store']);
Route::post('drugs', [DrugController::class, 'store']);
Route::post('user-drugs', [UserDrugController::class, 'store']);
Route::post('admins', [AdminController::class, 'store']);