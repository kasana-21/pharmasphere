

<?php
$T = array("a", "b", "c", "d");
foreach ($T as $val) {
    echo $val . '<br>';
}
?>
